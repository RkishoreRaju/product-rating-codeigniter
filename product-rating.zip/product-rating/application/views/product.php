<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.min.css'; ?>">
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/custom.css'; ?>">
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Product Rating</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" > <?php echo $_SESSION['username']; ?></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('User/logout'); ?>">Log Out</a>
      </li>

      </li>
    </ul>
  </div>
</nav>

<div class="container">
<div style="margin-bottom:15px;">
<a href="<?php echo base_url('profile');?>"><button class="btn btn-secondary">Go Back</button></a>
</div>

    <div class="card">
        <div class="card-body">
            <div class="row">
            <div class="col-md-6 text-center">
            <img src="<?php echo base_url('images/'.$product->product_image); ?>" style="border:2px solid #d4d4d4; padding:15px;"/>
            </div>
            <div class="col-md-4" style="padding-top:25px;">
              <p>Title : <?php echo $product->product_title; ?></p>
              <p>Description : <?php echo $product->product_desc; ?></p>
              <p>Price : <?php echo $product->product_price; ?></p> 

              <div class="product-rating"><span class="badge badge-success"> <?php echo round($rating->rate,1); ?> ★</span>&nbsp;&nbsp;&nbsp;<span class="rating-review"><?php echo $rating->num; ?> Customer Ratings</span></div>
                <br>
             <?php
                                if($rating_done == 0 ){
                            ?>
                                <hr class="singleline">
                                <div class="user-rating">
                                    <h4>Rate this Product:</h4>
                                    <form method="get" action="<?php echo base_url('profile/rate');?>">
                                        
                                <div class="rating">
                                
                                <input type="radio" id="star5" name="rating" value="5" /><label for="star5" title="Excellent">5 stars</label>
                                <input type="radio" id="star4" name="rating" value="4" /><label for="star4" title="Very Good">4 stars</label>
                                <input type="radio" id="star3" name="rating" value="3" /><label for="star3" title="Good">3 stars</label>
                                <input type="radio" id="star2" name="rating" value="2" /><label for="star2" title="Bad">2 stars</label>
                                <input type="radio" id="star1" name="rating" value="1" /><label for="star1" title="Very Bad">1 star</label>
                                </div>
        
                                        <input type="hidden" name="id" value="<?php echo $id; ?>" />
                                        <button class="btn btn-outline-success my-3" style="display: block;left: 20px;" type="submit">
                                            Submit
                                        </button>
                                    </form>
                                </div>
                                <?php } 
                                else{
                                    ?>
                                    <p class="text-success">You have Already Rated this product</p>
                                    <?php
                                }
                                ?>
            </div>
            </div>
        </div>
    </div>

    
</div>



<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>