<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.min.css'; ?>">
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/custom.css'; ?>">
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Product Rating</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="#"> <?php echo $_SESSION['username']; ?></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('User/logout'); ?>">Log Out</a>
      </li>

      </li>
    </ul>
  </div>
</nav>
<br>
<div class="container text-center">
<?php if(isset($_SESSION['success']))
            {?>
                <div class="alert alert-success" style="margin-top:15px;margin-bottom:15px;"><?php echo $_SESSION['success']; ?></div>
            <?php
            } ?>
</div>


 
<div class="products"> 
    <?php if(!empty($products)) { foreach($products as $product) { 
      ?>
    <div class="product text-center">
              <img src="<?php echo base_url('images/'.$product['product_image']); ?>"/>
              <br>
              <br>
              <p>Title : <?php echo $product['product_title'] ?></p>
              <p>Description : <?php echo $product['product_desc']; ?></p>
              <p>Price : <?php echo $product['product_price']; ?></p> 
              <a href="<?php echo base_url('profile/show?id='.$product['id']); ?>"><button class="btn btn-secondary">Know More</button></a>
     </div>  
            

                    <?php } } else {?>
                            <div class="alert alert-danger text-center">No Records Found</div>
       
                    <?php }?>


  </div>


 
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script> 

</body>
</html>