<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.min.css'; ?>">
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/custom.css'; ?>">
</head>
<body>


<div class="global-container">
        <div class="card login-form">
          <div class="card-body">
            <h3 class="card-title text-center">Log In</h3>
            <div class="card-text">
            <?php if(isset($_SESSION['success']))
            {?>
                <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
            <?php
            } ?>
         <?php if(isset($_SESSION['error']))
            {?>
                <div class="alert alert-danger"><?php echo $_SESSION['error']; ?></div>
            <?php
            } ?>
            <?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>
    
                <form action="" method="POST">  
                    <div class="form-group">
                        <label>User Name</label>
                        <input type="text"  name="username" value="<?php echo set_value('username'); ?>" class="form-control form-control-sm" placeholder="Enter Username">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" value="<?php echo set_value('password'); ?>"  class="form-control form-control-sm" placeholder="Enter Password">
                    </div>
                    <button type="submit" name="index" class="btn btn-primary btn-block">Log In</button>
                    
                    <div class="sign-up">
                        Don't have an account? <a href="<?php echo base_url('User/signup'); ?>">Create One</a>
                    </div>
                </form>


            </div>
          </div>
        </div>
    </div>

</body>
</html>