<?php

class Profile extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if(!isset($_SESSION['user_logged']))
        {
            $this->session->set_flashdata("error"," Please Login First To Access");
            redirect(base_url().'User/index');

        }
    }

public function index()
{

    $this->load->model('Product_Model');
    $data['products'] = $this->Product_Model->display();
    $this->load->view('profile',$data);


}
public function show()
{       

    $this->load->model('Product_Model');
    
    $id = $this->input->get('id');
    $username=$this->session->userdata('username');
    if($id==null){
        redirect(base_url('profile'));
        return;
    }
    $data['product']=$this->Product_Model->product($id);

    $data['id'] = $id;

    $data['rating_done']= $this->Product_Model->Rated($id,$username);
    
    $data['rating'] = $this->Product_Model->rating($id);
    $this->load->View("product",$data);
}


public function rate()
{
 
        $this->load->model('Product_Model');
            
        if(null== $this->session->userdata('username')){
            redirect(base_url('User'));
            return;
        }
        
        $id = $this->input->get('id');
        if($id==null){
            redirect(base_url('product'));
            return;
        }

        $rate = $this->input->get('rating');
        $username=$this->session->userdata('username');
        $this->Product_Model->rate($id,$rate,$username);

        $data['product']=$this->Product_Model->product($id);

    $data['id'] = $id;

    $data['rating_done']= $this->Product_Model->Rated($id,$username);
    
    $data['rating'] = $this->Product_Model->rating($id);
    $this->load->View("product",$data);        


}





}



?>