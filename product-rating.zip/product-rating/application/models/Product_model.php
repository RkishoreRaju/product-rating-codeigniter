<?php

class Product_model extends CI_model{



function display(){
   return $products = $this->db->get('product')->result_array();
}

public function product($id)
{
    $query = $this->db->query("select * from product where id='$id'");
    return $query->result()[0];
}

public function rating($id)
{
    $query = $this->db->query("select count(distinct username) as num ,avg(rate) as rate from ratings where product_id='$id'");
    return $query->result()[0];
}

public function Rated($id,$username){
    $query = $this->db->query("select * from ratings where product_id='$id' and username='$username'");
    return $query->num_rows();
}

public function rate($id,$rate,$username){
   $query = $this->db->query("insert into ratings(username,product_id,rate) values('$username','$id','$rate');");
   return $query;
}


}
?>