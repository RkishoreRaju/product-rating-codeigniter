<?php

class User extends CI_controller{


    function index()
    {   
        if(isset($_POST['index']))
        {
        $this->form_validation->set_rules('username','Username','required');
        $this->form_validation->set_rules('password','Password','required|min_length[5]');
        if($this->form_validation->run() == TRUE)
        {

            $username = $_POST['username'];
            $password = md5($_POST['password']);

            $this->db->select('*');
            $this->db->from('user');
            $this->db->where(array('username' => $username, 'password' => $password));
            $query = $this->db->get();
            $user = $query->row();

            if($user->email){
                $this->session->set_flashdata("success","Welcome Back $username ");
                $_SESSION['user_logged'] = TRUE;
                $_SESSION['username'] = $user->username;

                redirect(base_url().'Profile');
            }else{
                $this->session->set_flashdata("error","Please Register to Login");
                redirect(base_url().'User/index');
            }


        }
     }
        $this->load->view('login');
    }

 


    public function signup()
    {

        if(isset($_POST['signup']))
        {
            $this->form_validation->set_rules('username','Username','required|regex_match[/^[a-zA-Z0-9]+$/]|is_unique[user.username]',array(
				'is_unique'=>"Username already exits"
            ));
            $this->form_validation->set_rules('email','Email','required|valid_email');
            $this->form_validation->set_rules('password','Password','required|min_length[5]');
            if($this->form_validation->run() == TRUE)
            {
               
               $data = array(
                    'username' => $_POST['username'],
                    'email' => $_POST['email'],
                    'password' => md5($_POST['password'])
               );
               $this->db->insert('user',$data);

               $this->session->set_flashdata("success","You have successfully Registered .. Please Login To Access");
               redirect(base_url().'User/signup');
            }
        }
        $this->load->view('signup');

    }




public function logout()
{
    unset($_SESSION);
    session_destroy();
    redirect(base_url().'User/index');
}




}

?>